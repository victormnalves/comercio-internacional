```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from plotnine import * 
import geopandas as gpd
```


```python
##################################################2.1######################################################
#Item a)
#Importação da base de dados wdi:
wdi = pd.read_csv(r'C:\Users\david\OneDrive - Insper - Institudo de Ensino e Pesquisa\Insper\6º semestre\Comércio Internacional\com_int_dados_aps1/wdi.csv')
wdi
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>countryname</th>
      <th>countrycode</th>
      <th>indicatorname</th>
      <th>indicatorcode</th>
      <th>v1960</th>
      <th>v1961</th>
      <th>v1962</th>
      <th>v1963</th>
      <th>v1964</th>
      <th>v1965</th>
      <th>...</th>
      <th>v2012</th>
      <th>v2013</th>
      <th>v2014</th>
      <th>v2015</th>
      <th>v2016</th>
      <th>v2017</th>
      <th>v2018</th>
      <th>v2019</th>
      <th>v2020</th>
      <th>region</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>Logistics performance index: Competence and qu...</td>
      <td>LP.LPI.LOGS.XQ</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Latin America &amp; Caribbean</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>External debt stocks, private nonguaranteed (P...</td>
      <td>DT.DOD.DPNG.CD</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Latin America &amp; Caribbean</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>Time to resolve insolvency (years)</td>
      <td>IC.ISV.DURS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Latin America &amp; Caribbean</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>Level of water stress: freshwater withdrawal a...</td>
      <td>ER.H2O.FWST.ZS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Latin America &amp; Caribbean</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>Manufactures exports (% of merchandise exports)</td>
      <td>TX.VAL.MANF.ZS.UN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>19.143876</td>
      <td>20.004849</td>
      <td>26.266299</td>
      <td>31.860494</td>
      <td>32.587242</td>
      <td>34.540943</td>
      <td>44.056308</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Latin America &amp; Caribbean</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>311824</th>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Educational attainment, Doctoral or equivalent...</td>
      <td>SE.TER.CUAT.DO.ZS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.036750</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Sub-Saharan Africa</td>
    </tr>
    <tr>
      <th>311825</th>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>GNI per capita, PPP (current international $)</td>
      <td>NY.GNP.PCAP.PP.CD</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>2070.000000</td>
      <td>2310.000000</td>
      <td>2360.000000</td>
      <td>2410.000000</td>
      <td>2560.000000</td>
      <td>2760.000000</td>
      <td>2990.000000</td>
      <td>2730.000000</td>
      <td>NaN</td>
      <td>Sub-Saharan Africa</td>
    </tr>
    <tr>
      <th>311826</th>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Coverage of social insurance programs in 4th q...</td>
      <td>per_si_allsi.cov_q4_tot</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>4.778166</td>
      <td>NaN</td>
      <td>4.674356</td>
      <td>NaN</td>
      <td>Sub-Saharan Africa</td>
    </tr>
    <tr>
      <th>311827</th>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Informal payments to public officials (% of fi...</td>
      <td>IC.FRM.CORR.ZS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>14.400000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Sub-Saharan Africa</td>
    </tr>
    <tr>
      <th>311828</th>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Households and NPISHs final consumption expend...</td>
      <td>NE.CON.PRVT.ZS</td>
      <td>77.626339</td>
      <td>74.224942</td>
      <td>74.144418</td>
      <td>75.100027</td>
      <td>78.124847</td>
      <td>75.109494</td>
      <td>...</td>
      <td>93.973094</td>
      <td>87.032800</td>
      <td>83.611816</td>
      <td>89.515307</td>
      <td>83.346653</td>
      <td>79.358628</td>
      <td>77.038048</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Sub-Saharan Africa</td>
    </tr>
  </tbody>
</table>
<p>311829 rows × 66 columns</p>
</div>




```python
#Selecionando as colunas relevantes:
wdi_a = wdi[['countryname', 'countrycode', 'indicatorname', 'v2016']]
wdi_a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>countryname</th>
      <th>countrycode</th>
      <th>indicatorname</th>
      <th>v2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>Logistics performance index: Competence and qu...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>External debt stocks, private nonguaranteed (P...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>Time to resolve insolvency (years)</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>Level of water stress: freshwater withdrawal a...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>Manufactures exports (% of merchandise exports)</td>
      <td>32.587242</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>311824</th>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Educational attainment, Doctoral or equivalent...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>311825</th>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>GNI per capita, PPP (current international $)</td>
      <td>2560.000000</td>
    </tr>
    <tr>
      <th>311826</th>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Coverage of social insurance programs in 4th q...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>311827</th>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Informal payments to public officials (% of fi...</td>
      <td>14.400000</td>
    </tr>
    <tr>
      <th>311828</th>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Households and NPISHs final consumption expend...</td>
      <td>83.346653</td>
    </tr>
  </tbody>
</table>
<p>311829 rows × 4 columns</p>
</div>




```python
#Filtragem dos dados para obtenção de apenas a população e o PIB em 2016
wdi_a = wdi_a[(wdi_a['indicatorname'] == 'Population, total') | (wdi_a['indicatorname'] == 'GDP (current US$)')]
wdi_a

#Renomeando v2016:
wdi_a = wdi_a.rename(columns={'v2016':'2016'})
wdi_a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>countryname</th>
      <th>countrycode</th>
      <th>indicatorname</th>
      <th>2016</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>98</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>GDP (current US$)</td>
      <td>2.965922e+09</td>
    </tr>
    <tr>
      <th>1207</th>
      <td>Aruba</td>
      <td>ABW</td>
      <td>Population, total</td>
      <td>1.048720e+05</td>
    </tr>
    <tr>
      <th>1999</th>
      <td>Afghanistan</td>
      <td>AFG</td>
      <td>Population, total</td>
      <td>3.538313e+07</td>
    </tr>
    <tr>
      <th>2432</th>
      <td>Afghanistan</td>
      <td>AFG</td>
      <td>GDP (current US$)</td>
      <td>1.936264e+10</td>
    </tr>
    <tr>
      <th>3356</th>
      <td>Angola</td>
      <td>AGO</td>
      <td>GDP (current US$)</td>
      <td>1.011239e+11</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>308862</th>
      <td>South Africa</td>
      <td>ZAF</td>
      <td>GDP (current US$)</td>
      <td>2.963573e+11</td>
    </tr>
    <tr>
      <th>309285</th>
      <td>Zambia</td>
      <td>ZMB</td>
      <td>GDP (current US$)</td>
      <td>2.095476e+10</td>
    </tr>
    <tr>
      <th>310228</th>
      <td>Zambia</td>
      <td>ZMB</td>
      <td>Population, total</td>
      <td>1.636351e+07</td>
    </tr>
    <tr>
      <th>311123</th>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>GDP (current US$)</td>
      <td>2.054868e+10</td>
    </tr>
    <tr>
      <th>311380</th>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Population, total</td>
      <td>1.403039e+07</td>
    </tr>
  </tbody>
</table>
<p>434 rows × 4 columns</p>
</div>




```python
#Pivotando a tabela para ter cada país em uma linha e as informações em colunas:
wdi_a = wdi_a.pivot(index='countryname', columns='indicatorname', values='2016').reset_index()
wdi_a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>indicatorname</th>
      <th>countryname</th>
      <th>GDP (current US$)</th>
      <th>Population, total</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>1.936264e+10</td>
      <td>35383128.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Albania</td>
      <td>1.186120e+10</td>
      <td>2876101.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Algeria</td>
      <td>1.600338e+11</td>
      <td>40551404.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>American Samoa</td>
      <td>6.520000e+08</td>
      <td>55741.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Andorra</td>
      <td>2.896679e+09</td>
      <td>77297.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>212</th>
      <td>Virgin Islands (U.S.)</td>
      <td>3.863000e+09</td>
      <td>107510.0</td>
    </tr>
    <tr>
      <th>213</th>
      <td>West Bank and Gaza</td>
      <td>1.342570e+10</td>
      <td>4367088.0</td>
    </tr>
    <tr>
      <th>214</th>
      <td>Yemen, Rep.</td>
      <td>2.808468e+10</td>
      <td>27168210.0</td>
    </tr>
    <tr>
      <th>215</th>
      <td>Zambia</td>
      <td>2.095476e+10</td>
      <td>16363507.0</td>
    </tr>
    <tr>
      <th>216</th>
      <td>Zimbabwe</td>
      <td>2.054868e+10</td>
      <td>14030390.0</td>
    </tr>
  </tbody>
</table>
<p>217 rows × 3 columns</p>
</div>




```python
#Renomeando as colunas:
wdi_a.columns = ['Country', 'GDP', 'Population']
wdi_a

#Conversão do PIB para bilhões de U$:
wdi_a['GDP'] = wdi_a['GDP'] / 10**9
wdi_a
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>GDP</th>
      <th>Population</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>19.362642</td>
      <td>35383128.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Albania</td>
      <td>11.861201</td>
      <td>2876101.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Algeria</td>
      <td>160.033844</td>
      <td>40551404.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>American Samoa</td>
      <td>0.652000</td>
      <td>55741.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Andorra</td>
      <td>2.896679</td>
      <td>77297.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>212</th>
      <td>Virgin Islands (U.S.)</td>
      <td>3.863000</td>
      <td>107510.0</td>
    </tr>
    <tr>
      <th>213</th>
      <td>West Bank and Gaza</td>
      <td>13.425700</td>
      <td>4367088.0</td>
    </tr>
    <tr>
      <th>214</th>
      <td>Yemen, Rep.</td>
      <td>28.084676</td>
      <td>27168210.0</td>
    </tr>
    <tr>
      <th>215</th>
      <td>Zambia</td>
      <td>20.954762</td>
      <td>16363507.0</td>
    </tr>
    <tr>
      <th>216</th>
      <td>Zimbabwe</td>
      <td>20.548678</td>
      <td>14030390.0</td>
    </tr>
  </tbody>
</table>
<p>217 rows × 3 columns</p>
</div>




```python
##############################################Item b)##########################################################
```


```python
##Importação da base de dados itpd:
itpd = pd.read_stata(r'C:\Users\david\OneDrive - Insper - Institudo de Ensino e Pesquisa\Insper\6º semestre\Comércio Internacional\com_int_dados_aps1/itpd.dta')
itpd
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>exporter_iso3</th>
      <th>exporter_m49</th>
      <th>importer_iso3</th>
      <th>importer_m49</th>
      <th>year</th>
      <th>industry_id</th>
      <th>broad_sector</th>
      <th>trade</th>
      <th>flag_mirror</th>
      <th>flag_zero</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2000</td>
      <td>Refined petroleum products</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2000</td>
      <td>Structural metal products</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2000</td>
      <td>Pumps compressors taps and valves</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2000</td>
      <td>Other general purpose machinery</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2000</td>
      <td>TV and radio receivers and associated goods</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>38518232</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>2016</td>
      <td>Corn</td>
      <td>Agriculture</td>
      <td>331.533470</td>
      <td>Reported value</td>
      <td>p: Positive trade flow</td>
    </tr>
    <tr>
      <th>38518233</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>2016</td>
      <td>Other cereals</td>
      <td>Agriculture</td>
      <td>29.803773</td>
      <td>Reported value</td>
      <td>p: Positive trade flow</td>
    </tr>
    <tr>
      <th>38518234</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>2016</td>
      <td>Soybeans</td>
      <td>Agriculture</td>
      <td>38.413000</td>
      <td>Reported value</td>
      <td>p: Positive trade flow</td>
    </tr>
    <tr>
      <th>38518235</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>2016</td>
      <td>Other oilseeds (excluding peanuts)</td>
      <td>Agriculture</td>
      <td>27.450000</td>
      <td>Reported value</td>
      <td>p: Positive trade flow</td>
    </tr>
    <tr>
      <th>38518236</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>2016</td>
      <td>Pulses and legumes, dried, preserved</td>
      <td>Agriculture</td>
      <td>14.574307</td>
      <td>Reported value</td>
      <td>p: Positive trade flow</td>
    </tr>
  </tbody>
</table>
<p>38518237 rows × 10 columns</p>
</div>




```python
#Exclusão do comércio doméstico:
itpd = itpd[itpd['exporter_iso3'] != itpd['importer_iso3']]
itpd
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>exporter_iso3</th>
      <th>exporter_m49</th>
      <th>importer_iso3</th>
      <th>importer_m49</th>
      <th>year</th>
      <th>industry_id</th>
      <th>broad_sector</th>
      <th>trade</th>
      <th>flag_mirror</th>
      <th>flag_zero</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2000</td>
      <td>Refined petroleum products</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2000</td>
      <td>Structural metal products</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2000</td>
      <td>Pumps compressors taps and valves</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2000</td>
      <td>Other general purpose machinery</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2000</td>
      <td>TV and radio receivers and associated goods</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>38518190</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZMB</td>
      <td>Zambia</td>
      <td>2016</td>
      <td>Jewellery and related articles</td>
      <td>Manufacturing</td>
      <td>0.010282</td>
      <td>Mirror value</td>
      <td>p: Positive trade flow</td>
    </tr>
    <tr>
      <th>38518191</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZMB</td>
      <td>Zambia</td>
      <td>2016</td>
      <td>Musical instruments</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>38518192</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZMB</td>
      <td>Zambia</td>
      <td>2016</td>
      <td>Sports goods</td>
      <td>Manufacturing</td>
      <td>0.000115</td>
      <td>Mirror value</td>
      <td>p: Positive trade flow</td>
    </tr>
    <tr>
      <th>38518193</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZMB</td>
      <td>Zambia</td>
      <td>2016</td>
      <td>Games and toys</td>
      <td>Manufacturing</td>
      <td>0.002748</td>
      <td>Mirror value</td>
      <td>p: Positive trade flow</td>
    </tr>
    <tr>
      <th>38518194</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZMB</td>
      <td>Zambia</td>
      <td>2016</td>
      <td>Other manufacturing n.e.c.</td>
      <td>Manufacturing</td>
      <td>0.364066</td>
      <td>Mirror value</td>
      <td>p: Positive trade flow</td>
    </tr>
  </tbody>
</table>
<p>38409788 rows × 10 columns</p>
</div>




```python
#Selecionando apenas o ano de 2016:
itpd_2016 = itpd.loc[itpd['year'] == 2016]
itpd_2016
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>exporter_iso3</th>
      <th>exporter_m49</th>
      <th>importer_iso3</th>
      <th>importer_m49</th>
      <th>year</th>
      <th>industry_id</th>
      <th>broad_sector</th>
      <th>trade</th>
      <th>flag_mirror</th>
      <th>flag_zero</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>144</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2016</td>
      <td>Refined petroleum products</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>145</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2016</td>
      <td>Structural metal products</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>146</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2016</td>
      <td>Pumps compressors taps and valves</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>147</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2016</td>
      <td>Other general purpose machinery</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>148</th>
      <td>ABW</td>
      <td>Aruba</td>
      <td>AGO</td>
      <td>Angola</td>
      <td>2016</td>
      <td>TV and radio receivers and associated goods</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>38518190</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZMB</td>
      <td>Zambia</td>
      <td>2016</td>
      <td>Jewellery and related articles</td>
      <td>Manufacturing</td>
      <td>0.010282</td>
      <td>Mirror value</td>
      <td>p: Positive trade flow</td>
    </tr>
    <tr>
      <th>38518191</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZMB</td>
      <td>Zambia</td>
      <td>2016</td>
      <td>Musical instruments</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
      <td>Reported value</td>
      <td>u: Missing (unknown, assigned zero)</td>
    </tr>
    <tr>
      <th>38518192</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZMB</td>
      <td>Zambia</td>
      <td>2016</td>
      <td>Sports goods</td>
      <td>Manufacturing</td>
      <td>0.000115</td>
      <td>Mirror value</td>
      <td>p: Positive trade flow</td>
    </tr>
    <tr>
      <th>38518193</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZMB</td>
      <td>Zambia</td>
      <td>2016</td>
      <td>Games and toys</td>
      <td>Manufacturing</td>
      <td>0.002748</td>
      <td>Mirror value</td>
      <td>p: Positive trade flow</td>
    </tr>
    <tr>
      <th>38518194</th>
      <td>ZWE</td>
      <td>Zimbabwe</td>
      <td>ZMB</td>
      <td>Zambia</td>
      <td>2016</td>
      <td>Other manufacturing n.e.c.</td>
      <td>Manufacturing</td>
      <td>0.364066</td>
      <td>Mirror value</td>
      <td>p: Positive trade flow</td>
    </tr>
  </tbody>
</table>
<p>2258199 rows × 10 columns</p>
</div>




```python
#Criando uma base para exportações:
itpd_e = itpd_2016[['exporter_m49','industry_id','broad_sector','trade']]
itpd_e.rename(columns = {'exporter_m49':'Country'}, inplace = True)
itpd_e
```

    C:\Users\david\AppData\Local\Temp\ipykernel_1756\3031610951.py:3: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>industry_id</th>
      <th>broad_sector</th>
      <th>trade</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>144</th>
      <td>Aruba</td>
      <td>Refined petroleum products</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>145</th>
      <td>Aruba</td>
      <td>Structural metal products</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>146</th>
      <td>Aruba</td>
      <td>Pumps compressors taps and valves</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>147</th>
      <td>Aruba</td>
      <td>Other general purpose machinery</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>148</th>
      <td>Aruba</td>
      <td>TV and radio receivers and associated goods</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>38518190</th>
      <td>Zimbabwe</td>
      <td>Jewellery and related articles</td>
      <td>Manufacturing</td>
      <td>0.010282</td>
    </tr>
    <tr>
      <th>38518191</th>
      <td>Zimbabwe</td>
      <td>Musical instruments</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>38518192</th>
      <td>Zimbabwe</td>
      <td>Sports goods</td>
      <td>Manufacturing</td>
      <td>0.000115</td>
    </tr>
    <tr>
      <th>38518193</th>
      <td>Zimbabwe</td>
      <td>Games and toys</td>
      <td>Manufacturing</td>
      <td>0.002748</td>
    </tr>
    <tr>
      <th>38518194</th>
      <td>Zimbabwe</td>
      <td>Other manufacturing n.e.c.</td>
      <td>Manufacturing</td>
      <td>0.364066</td>
    </tr>
  </tbody>
</table>
<p>2258199 rows × 4 columns</p>
</div>




```python
#Criando uma base para importações:
itpd_i = itpd_2016[['importer_m49','industry_id','broad_sector','trade']]
itpd_i.rename(columns = {'importer_m49':'Country'}, inplace = True)
itpd_i
```

    C:\Users\david\AppData\Local\Temp\ipykernel_1756\1896646475.py:3: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>industry_id</th>
      <th>broad_sector</th>
      <th>trade</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>144</th>
      <td>Angola</td>
      <td>Refined petroleum products</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>145</th>
      <td>Angola</td>
      <td>Structural metal products</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>146</th>
      <td>Angola</td>
      <td>Pumps compressors taps and valves</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>147</th>
      <td>Angola</td>
      <td>Other general purpose machinery</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>148</th>
      <td>Angola</td>
      <td>TV and radio receivers and associated goods</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>38518190</th>
      <td>Zambia</td>
      <td>Jewellery and related articles</td>
      <td>Manufacturing</td>
      <td>0.010282</td>
    </tr>
    <tr>
      <th>38518191</th>
      <td>Zambia</td>
      <td>Musical instruments</td>
      <td>Manufacturing</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>38518192</th>
      <td>Zambia</td>
      <td>Sports goods</td>
      <td>Manufacturing</td>
      <td>0.000115</td>
    </tr>
    <tr>
      <th>38518193</th>
      <td>Zambia</td>
      <td>Games and toys</td>
      <td>Manufacturing</td>
      <td>0.002748</td>
    </tr>
    <tr>
      <th>38518194</th>
      <td>Zambia</td>
      <td>Other manufacturing n.e.c.</td>
      <td>Manufacturing</td>
      <td>0.364066</td>
    </tr>
  </tbody>
</table>
<p>2258199 rows × 4 columns</p>
</div>




```python
# selecionando variáveis relevantes
itpd_e = itpd_2016[['exporter_m49', 'broad_sector', 'trade']] 
# renomeando as variáveis
itpd_e = itpd_e.rename(columns={'exporter_m49': 'Country', 'trade': 'exports'})
# modificando os tipos das variáveis
itpd_e['Country'] = itpd_e['Country'].astype('category')
itpd_e['broad_sector'] = itpd['broad_sector'].astype('category')
# convertendo para bilhões de U$:
itpd_e['exports'] = pd.to_numeric(itpd_e['exports'])/10**3
# ordenando os dados por variáveis categóricas para facilitar junção das bases
itpd_e = itpd_e.sort_values(by=['Country', 'broad_sector']).reset_index(drop=True)

# selecionando variáveis relevantes
itpd_i = itpd_2016[['importer_m49', 'broad_sector', 'trade']]
# renomeando as variáveis
itpd_i = itpd_i.rename(columns={'importer_m49': 'Country2', 'trade': 'imports', 'broad_sector': 'broad_sector2'})
# modificando os tipos das variáveis
itpd_i['Country2'] = itpd_i['Country2'].astype('category')
itpd_i['broad_sector2'] = itpd_i['broad_sector2'].astype('category')
#Convertendo para bilhões de U$:
itpd_i['imports'] = pd.to_numeric(itpd_i['imports'])/10**3
# ordenando os dados por variáveis categóricas para facilitar junção das bases
itpd_i = itpd_i.sort_values(by=['Country2', 'broad_sector2']).reset_index(drop=True)
# unindo bases de exportação e importação
itpd_ie = pd.concat([itpd_e, itpd_i], axis=1)
itpd_ie.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>broad_sector</th>
      <th>exports</th>
      <th>Country2</th>
      <th>broad_sector2</th>
      <th>imports</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000022</td>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000000</td>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000004</td>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000534</td>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.001114</td>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000112</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000017</td>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000085</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000242</td>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.002156</td>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.009479</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.001016</td>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.012054</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000104</td>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000025</td>
    </tr>
  </tbody>
</table>
</div>




```python
# selecionando apenas variáveis relevantes
itpd_ie = itpd_ie[['Country', 'broad_sector', 'exports', 'imports']]
# criando a balança comercial
itpd_ie['trade_balance'] = itpd_ie['exports'] - itpd_ie['imports']
itpd_ie.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>broad_sector</th>
      <th>exports</th>
      <th>imports</th>
      <th>trade_balance</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000022</td>
      <td>0.000000</td>
      <td>0.000022</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000004</td>
      <td>0.000000</td>
      <td>0.000004</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000534</td>
      <td>0.000000</td>
      <td>0.000534</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.001114</td>
      <td>0.000112</td>
      <td>0.001002</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000017</td>
      <td>0.000085</td>
      <td>-0.000068</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000242</td>
      <td>0.000000</td>
      <td>0.000242</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.002156</td>
      <td>0.009479</td>
      <td>-0.007323</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.001016</td>
      <td>0.012054</td>
      <td>-0.011038</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>0.000104</td>
      <td>0.000025</td>
      <td>0.000079</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Criando importações e exportações totais por país e por setor

#Agregando variáveis numéricas:
itpd_ie_sector = itpd_ie.groupby(['Country', 'broad_sector']).agg(exports=('exports', 'sum'), imports=('imports', 'sum'), trade_balance=('trade_balance', 'sum')).reset_index()
# renomeando as colunas
itpd_ie_sector.columns = ['Country', 'broad_sector', 'exports', 'imports', 'trade_balance']
# transformando a bases em um dataframe
itpd_ie_sector = pd.DataFrame(itpd_ie_sector)
# calculando o comércio total
itpd_ie_sector['total_commerce'] = itpd_ie_sector['exports'] + itpd_ie_sector['imports']

itpd_ie_sector.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>broad_sector</th>
      <th>exports</th>
      <th>imports</th>
      <th>trade_balance</th>
      <th>total_commerce</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>Agriculture</td>
      <td>4.892683e-01</td>
      <td>0.472355</td>
      <td>1.691287e-02</td>
      <td>9.616237e-01</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>Mining &amp; Energy</td>
      <td>9.757177e-02</td>
      <td>0.006542</td>
      <td>9.102996e-02</td>
      <td>1.041136e-01</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Afghanistan</td>
      <td>Manufacturing</td>
      <td>3.192499e-01</td>
      <td>4.962128</td>
      <td>-4.642878e+00</td>
      <td>5.281378e+00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Afghanistan</td>
      <td>Services</td>
      <td>1.300000e-03</td>
      <td>0.020979</td>
      <td>-1.967901e-02</td>
      <td>2.227901e-02</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Albania</td>
      <td>Agriculture</td>
      <td>1.080260e-01</td>
      <td>0.858472</td>
      <td>-7.504462e-01</td>
      <td>9.664982e-01</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Albania</td>
      <td>Mining &amp; Energy</td>
      <td>5.116979e-01</td>
      <td>0.020946</td>
      <td>4.907519e-01</td>
      <td>5.326439e-01</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Albania</td>
      <td>Manufacturing</td>
      <td>1.533651e+00</td>
      <td>3.469467</td>
      <td>-1.935817e+00</td>
      <td>5.003118e+00</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Albania</td>
      <td>Services</td>
      <td>1.000000e-04</td>
      <td>0.004204</td>
      <td>-4.103709e-03</td>
      <td>4.303709e-03</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Antarctica</td>
      <td>Agriculture</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Antarctica</td>
      <td>Mining &amp; Energy</td>
      <td>2.490000e-07</td>
      <td>0.000000</td>
      <td>2.490000e-07</td>
      <td>2.490000e-07</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Criando importações e exportações totais por país
itpd_ie_total = itpd_ie.groupby(['Country']).agg(exports=('exports', 'sum'), imports=('imports', 'sum'), trade_balance=('trade_balance', 'sum')).reset_index()
# renomeando as colunas
itpd_ie_total.columns = ['Country', 'exports', 'imports', 'trade_balance']
# transformando a bases em um dataframe
itpd_ie_total = pd.DataFrame(itpd_ie_total)
# calculando o comércio total
itpd_ie_total['total_commerce'] = itpd_ie_total['exports'] + itpd_ie_total['imports']

itpd_ie_total.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>exports</th>
      <th>imports</th>
      <th>trade_balance</th>
      <th>total_commerce</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>0.907390</td>
      <td>5.462004</td>
      <td>-4.554614</td>
      <td>6.369394</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Albania</td>
      <td>2.153475</td>
      <td>4.353089</td>
      <td>-2.199614</td>
      <td>6.506564</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Antarctica</td>
      <td>0.008771</td>
      <td>0.118942</td>
      <td>-0.110170</td>
      <td>0.127713</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Algeria</td>
      <td>30.914690</td>
      <td>29.175478</td>
      <td>1.739213</td>
      <td>60.090168</td>
    </tr>
    <tr>
      <th>4</th>
      <td>American Samoa</td>
      <td>0.040456</td>
      <td>9.925414</td>
      <td>-9.884958</td>
      <td>9.965870</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Andorra</td>
      <td>0.096728</td>
      <td>9.233462</td>
      <td>-9.136734</td>
      <td>9.330190</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Angola</td>
      <td>27.971460</td>
      <td>1.264365</td>
      <td>26.707096</td>
      <td>29.235825</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Antigua and Barbuda</td>
      <td>0.267803</td>
      <td>4.210697</td>
      <td>-3.942894</td>
      <td>4.478500</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Azerbaijan</td>
      <td>12.563601</td>
      <td>5.289180</td>
      <td>7.274422</td>
      <td>17.852781</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Argentina</td>
      <td>64.504365</td>
      <td>6.228955</td>
      <td>58.275410</td>
      <td>70.733320</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Combinando informações de comércio por setor e país e do Banco Mundial:
final_database_sector = pd.merge(wdi_a, itpd_ie_sector, on = 'Country', how = 'right')
final_database_sector.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>GDP</th>
      <th>Population</th>
      <th>broad_sector</th>
      <th>exports</th>
      <th>imports</th>
      <th>trade_balance</th>
      <th>total_commerce</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>19.362642</td>
      <td>35383128.0</td>
      <td>Agriculture</td>
      <td>0.489268</td>
      <td>0.472355</td>
      <td>0.016913</td>
      <td>0.961624</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>19.362642</td>
      <td>35383128.0</td>
      <td>Mining &amp; Energy</td>
      <td>0.097572</td>
      <td>0.006542</td>
      <td>0.091030</td>
      <td>0.104114</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Afghanistan</td>
      <td>19.362642</td>
      <td>35383128.0</td>
      <td>Manufacturing</td>
      <td>0.319250</td>
      <td>4.962128</td>
      <td>-4.642878</td>
      <td>5.281378</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Afghanistan</td>
      <td>19.362642</td>
      <td>35383128.0</td>
      <td>Services</td>
      <td>0.001300</td>
      <td>0.020979</td>
      <td>-0.019679</td>
      <td>0.022279</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Albania</td>
      <td>11.861201</td>
      <td>2876101.0</td>
      <td>Agriculture</td>
      <td>0.108026</td>
      <td>0.858472</td>
      <td>-0.750446</td>
      <td>0.966498</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Combinando informações de comércio por país e do Banco Mundial:
final_database_total = pd.merge(wdi_a, itpd_ie_total, on = 'Country', how = 'right')
final_database_total
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>GDP</th>
      <th>Population</th>
      <th>exports</th>
      <th>imports</th>
      <th>trade_balance</th>
      <th>total_commerce</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>19.362642</td>
      <td>35383128.0</td>
      <td>0.907390</td>
      <td>5.462004</td>
      <td>-4.554614</td>
      <td>6.369394</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Albania</td>
      <td>11.861201</td>
      <td>2876101.0</td>
      <td>2.153475</td>
      <td>4.353089</td>
      <td>-2.199614</td>
      <td>6.506564</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Antarctica</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.008771</td>
      <td>0.118942</td>
      <td>-0.110170</td>
      <td>0.127713</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Algeria</td>
      <td>160.033844</td>
      <td>40551404.0</td>
      <td>30.914690</td>
      <td>29.175478</td>
      <td>1.739213</td>
      <td>60.090168</td>
    </tr>
    <tr>
      <th>4</th>
      <td>American Samoa</td>
      <td>0.652000</td>
      <td>55741.0</td>
      <td>0.040456</td>
      <td>9.925414</td>
      <td>-9.884958</td>
      <td>9.965870</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>236</th>
      <td>Wallis and Futuna Islands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000386</td>
      <td>0.344644</td>
      <td>-0.344258</td>
      <td>0.345030</td>
    </tr>
    <tr>
      <th>237</th>
      <td>Samoa</td>
      <td>0.799376</td>
      <td>194535.0</td>
      <td>0.183128</td>
      <td>1.781010</td>
      <td>-1.597882</td>
      <td>1.964138</td>
    </tr>
    <tr>
      <th>238</th>
      <td>Yemen</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.859306</td>
      <td>1.589627</td>
      <td>-0.730321</td>
      <td>2.448933</td>
    </tr>
    <tr>
      <th>239</th>
      <td>Serbia and Montenegro</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>240</th>
      <td>Zambia</td>
      <td>20.954762</td>
      <td>16363507.0</td>
      <td>5.481148</td>
      <td>3.020655</td>
      <td>2.460492</td>
      <td>8.501803</td>
    </tr>
  </tbody>
</table>
<p>241 rows × 7 columns</p>
</div>




```python
#Criando uma nova coluna com os dados em ln para exportações e importações
final_database_total["ln(exports)"] = np.log(final_database_total["exports"])
final_database_total["ln(imports)"] = np.log(final_database_total["imports"])
final_database_total

```

    C:\Users\david\anaconda3\lib\site-packages\pandas\core\arraylike.py:397: RuntimeWarning: divide by zero encountered in log
    C:\Users\david\anaconda3\lib\site-packages\pandas\core\arraylike.py:397: RuntimeWarning: divide by zero encountered in log
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>GDP</th>
      <th>Population</th>
      <th>exports</th>
      <th>imports</th>
      <th>trade_balance</th>
      <th>total_commerce</th>
      <th>ln(exports)</th>
      <th>ln(imports)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>19.362642</td>
      <td>35383128.0</td>
      <td>0.907390</td>
      <td>5.462004</td>
      <td>-4.554614</td>
      <td>6.369394</td>
      <td>-0.097183</td>
      <td>1.697816</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Albania</td>
      <td>11.861201</td>
      <td>2876101.0</td>
      <td>2.153475</td>
      <td>4.353089</td>
      <td>-2.199614</td>
      <td>6.506564</td>
      <td>0.767083</td>
      <td>1.470886</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Antarctica</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.008771</td>
      <td>0.118942</td>
      <td>-0.110170</td>
      <td>0.127713</td>
      <td>-4.736266</td>
      <td>-2.129122</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Algeria</td>
      <td>160.033844</td>
      <td>40551404.0</td>
      <td>30.914690</td>
      <td>29.175478</td>
      <td>1.739213</td>
      <td>60.090168</td>
      <td>3.431231</td>
      <td>3.373329</td>
    </tr>
    <tr>
      <th>4</th>
      <td>American Samoa</td>
      <td>0.652000</td>
      <td>55741.0</td>
      <td>0.040456</td>
      <td>9.925414</td>
      <td>-9.884958</td>
      <td>9.965870</td>
      <td>-3.207545</td>
      <td>2.295099</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>236</th>
      <td>Wallis and Futuna Islands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000386</td>
      <td>0.344644</td>
      <td>-0.344258</td>
      <td>0.345030</td>
      <td>-7.860593</td>
      <td>-1.065243</td>
    </tr>
    <tr>
      <th>237</th>
      <td>Samoa</td>
      <td>0.799376</td>
      <td>194535.0</td>
      <td>0.183128</td>
      <td>1.781010</td>
      <td>-1.597882</td>
      <td>1.964138</td>
      <td>-1.697569</td>
      <td>0.577181</td>
    </tr>
    <tr>
      <th>238</th>
      <td>Yemen</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.859306</td>
      <td>1.589627</td>
      <td>-0.730321</td>
      <td>2.448933</td>
      <td>-0.151630</td>
      <td>0.463499</td>
    </tr>
    <tr>
      <th>239</th>
      <td>Serbia and Montenegro</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-inf</td>
      <td>-inf</td>
    </tr>
    <tr>
      <th>240</th>
      <td>Zambia</td>
      <td>20.954762</td>
      <td>16363507.0</td>
      <td>5.481148</td>
      <td>3.020655</td>
      <td>2.460492</td>
      <td>8.501803</td>
      <td>1.701315</td>
      <td>1.105474</td>
    </tr>
  </tbody>
</table>
<p>241 rows × 9 columns</p>
</div>




```python
#####################################2.2####################################################################
```


```python
#########################################Item a)############################################################
ggplot(final_database_total, aes(x="ln(exports)", y="ln(imports)", size="GDP")) + \
    geom_point(alpha=0.8, fill="darkblue") + \
    labs(x="Ln Exportações (bilhões de U$)", y="Ln Importações (bilhões de U$)", \
         title="Exportações x Importações ponderada pelo PIB") + \
    geom_smooth(method="lm", color="red", se=False, show_legend=False) + \
    theme_classic()
```

    C:\Users\david\anaconda3\lib\site-packages\plotnine\layer.py:411: PlotnineWarning: geom_point : Removed 64 rows containing missing values.
    


    
![png](output_20_1.png)
    





    <ggplot: (166482611330)>




```python
##########################################Item b)###########################################################
final_database_total["total_commerce/GDP"] = final_database_total["total_commerce"]/final_database_total["GDP"]
final_database_total

final_database_total["ln(GDP)"] = np.log(final_database_total["GDP"])
final_database_total
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>GDP</th>
      <th>Population</th>
      <th>exports</th>
      <th>imports</th>
      <th>trade_balance</th>
      <th>total_commerce</th>
      <th>ln(exports)</th>
      <th>ln(imports)</th>
      <th>total_commerce/GDP</th>
      <th>ln(GDP)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>19.362642</td>
      <td>35383128.0</td>
      <td>0.907390</td>
      <td>5.462004</td>
      <td>-4.554614</td>
      <td>6.369394</td>
      <td>-0.097183</td>
      <td>1.697816</td>
      <td>0.328953</td>
      <td>2.963346</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Albania</td>
      <td>11.861201</td>
      <td>2876101.0</td>
      <td>2.153475</td>
      <td>4.353089</td>
      <td>-2.199614</td>
      <td>6.506564</td>
      <td>0.767083</td>
      <td>1.470886</td>
      <td>0.548559</td>
      <td>2.473273</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Antarctica</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.008771</td>
      <td>0.118942</td>
      <td>-0.110170</td>
      <td>0.127713</td>
      <td>-4.736266</td>
      <td>-2.129122</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Algeria</td>
      <td>160.033844</td>
      <td>40551404.0</td>
      <td>30.914690</td>
      <td>29.175478</td>
      <td>1.739213</td>
      <td>60.090168</td>
      <td>3.431231</td>
      <td>3.373329</td>
      <td>0.375484</td>
      <td>5.075385</td>
    </tr>
    <tr>
      <th>4</th>
      <td>American Samoa</td>
      <td>0.652000</td>
      <td>55741.0</td>
      <td>0.040456</td>
      <td>9.925414</td>
      <td>-9.884958</td>
      <td>9.965870</td>
      <td>-3.207545</td>
      <td>2.295099</td>
      <td>15.285076</td>
      <td>-0.427711</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>236</th>
      <td>Wallis and Futuna Islands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000386</td>
      <td>0.344644</td>
      <td>-0.344258</td>
      <td>0.345030</td>
      <td>-7.860593</td>
      <td>-1.065243</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>237</th>
      <td>Samoa</td>
      <td>0.799376</td>
      <td>194535.0</td>
      <td>0.183128</td>
      <td>1.781010</td>
      <td>-1.597882</td>
      <td>1.964138</td>
      <td>-1.697569</td>
      <td>0.577181</td>
      <td>2.457088</td>
      <td>-0.223923</td>
    </tr>
    <tr>
      <th>238</th>
      <td>Yemen</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.859306</td>
      <td>1.589627</td>
      <td>-0.730321</td>
      <td>2.448933</td>
      <td>-0.151630</td>
      <td>0.463499</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239</th>
      <td>Serbia and Montenegro</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-inf</td>
      <td>-inf</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>240</th>
      <td>Zambia</td>
      <td>20.954762</td>
      <td>16363507.0</td>
      <td>5.481148</td>
      <td>3.020655</td>
      <td>2.460492</td>
      <td>8.501803</td>
      <td>1.701315</td>
      <td>1.105474</td>
      <td>0.405722</td>
      <td>3.042366</td>
    </tr>
  </tbody>
</table>
<p>241 rows × 11 columns</p>
</div>




```python
#Gráfico com outliers:
(ggplot(final_database_total, aes(x = "ln(GDP)", y = "total_commerce/GDP")) + \
     geom_point(alpha = 0.8, color = "darkblue") + \
     labs(x = "Log do PIB (bilhões de U$)", y = "Comércio total/PIB (bilhões de U$)",
         title = "Comércio total como relação do PIB x log PIB") + \
     geom_smooth(method="lm", color="red", se=False, show_legend=False) + \
     theme_classic())
```

    C:\Users\david\anaconda3\lib\site-packages\plotnine\layer.py:411: PlotnineWarning: geom_point : Removed 64 rows containing missing values.
    


    
![png](output_22_1.png)
    





    <ggplot: (166497840984)>




```python
#Gráfico sem outliers:
(ggplot(final_database_total, aes(x = "ln(GDP)", y = "total_commerce/GDP")) + \
     geom_point(alpha = 0.8, color = "darkblue") + \
     labs(x = "Log do PIB (bilhões de U$)", y = "Comércio total/PIB (bilhões de U$)",
         title = "Comércio total como relação do PIB x log PIB") + \
     geom_smooth(method="lm", color="red", se=False, show_legend=False) + \
     ylim(0,20) + \
     theme_classic())
```

    C:\Users\david\anaconda3\lib\site-packages\plotnine\layer.py:411: PlotnineWarning: geom_point : Removed 73 rows containing missing values.
    C:\Users\david\anaconda3\lib\site-packages\plotnine\layer.py:411: PlotnineWarning: geom_smooth : Removed 15 rows containing missing values.
    


    
![png](output_23_1.png)
    





    <ggplot: (166497609457)>




```python
##########################################2.3#############################################################
#Item a)
#Retirando os dados desnecessários ao que pede o item:
final_database_sector = final_database_sector.drop(columns=["trade_balance", "total_commerce"])
final_database_sector["exports/pop"] = final_database_sector["exports"]/final_database_sector["Population"]
final_database_sector["imports/pop"] = final_database_sector["imports"]/final_database_sector["Population"]
final_database_sector.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>GDP</th>
      <th>Population</th>
      <th>broad_sector</th>
      <th>exports</th>
      <th>imports</th>
      <th>exports/pop</th>
      <th>imports/pop</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>19.362642</td>
      <td>35383128.0</td>
      <td>Agriculture</td>
      <td>4.892683e-01</td>
      <td>0.472355</td>
      <td>1.382773e-08</td>
      <td>1.334974e-08</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>19.362642</td>
      <td>35383128.0</td>
      <td>Mining &amp; Energy</td>
      <td>9.757177e-02</td>
      <td>0.006542</td>
      <td>2.757579e-09</td>
      <td>1.848852e-10</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Afghanistan</td>
      <td>19.362642</td>
      <td>35383128.0</td>
      <td>Manufacturing</td>
      <td>3.192499e-01</td>
      <td>4.962128</td>
      <td>9.022659e-09</td>
      <td>1.402399e-07</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Afghanistan</td>
      <td>19.362642</td>
      <td>35383128.0</td>
      <td>Services</td>
      <td>1.300000e-03</td>
      <td>0.020979</td>
      <td>3.674068e-11</td>
      <td>5.929099e-10</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Albania</td>
      <td>11.861201</td>
      <td>2876101.0</td>
      <td>Agriculture</td>
      <td>1.080260e-01</td>
      <td>0.858472</td>
      <td>3.755988e-08</td>
      <td>2.984847e-07</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Albania</td>
      <td>11.861201</td>
      <td>2876101.0</td>
      <td>Mining &amp; Energy</td>
      <td>5.116979e-01</td>
      <td>0.020946</td>
      <td>1.779137e-07</td>
      <td>7.282776e-09</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Albania</td>
      <td>11.861201</td>
      <td>2876101.0</td>
      <td>Manufacturing</td>
      <td>1.533651e+00</td>
      <td>3.469467</td>
      <td>5.332395e-07</td>
      <td>1.206309e-06</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Albania</td>
      <td>11.861201</td>
      <td>2876101.0</td>
      <td>Services</td>
      <td>1.000000e-04</td>
      <td>0.004204</td>
      <td>3.476929e-11</td>
      <td>1.461600e-09</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Antarctica</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Agriculture</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Antarctica</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Mining &amp; Energy</td>
      <td>2.490000e-07</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
final_a_exports_pc= final_database_sector.pivot(index='Country', columns='broad_sector', values='exports/pop').reset_index()
final_a_exports_pc.head(50)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>broad_sector</th>
      <th>Country</th>
      <th>Agriculture</th>
      <th>Mining &amp; Energy</th>
      <th>Manufacturing</th>
      <th>Services</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>1.382773e-08</td>
      <td>2.757579e-09</td>
      <td>9.022659e-09</td>
      <td>3.674068e-11</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Albania</td>
      <td>3.755988e-08</td>
      <td>1.779137e-07</td>
      <td>5.332395e-07</td>
      <td>3.476929e-11</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Algeria</td>
      <td>1.454845e-09</td>
      <td>5.128387e-07</td>
      <td>2.472852e-07</td>
      <td>7.792579e-10</td>
    </tr>
    <tr>
      <th>3</th>
      <td>American Samoa</td>
      <td>2.951203e-09</td>
      <td>9.036130e-08</td>
      <td>6.324697e-07</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Andorra</td>
      <td>1.125529e-09</td>
      <td>3.687206e-10</td>
      <td>1.242122e-06</td>
      <td>7.762268e-09</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Angola</td>
      <td>4.281878e-11</td>
      <td>9.427116e-07</td>
      <td>2.687985e-08</td>
      <td>1.664212e-10</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Anguilla</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Antarctica</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Antigua and Barbuda</td>
      <td>3.935384e-08</td>
      <td>1.950765e-11</td>
      <td>2.793712e-06</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Argentina</td>
      <td>3.559084e-07</td>
      <td>4.461524e-08</td>
      <td>1.001994e-06</td>
      <td>7.726686e-08</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Armenia</td>
      <td>1.960700e-08</td>
      <td>2.888693e-07</td>
      <td>3.910858e-07</td>
      <td>4.996346e-08</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Aruba</td>
      <td>3.088527e-08</td>
      <td>1.142669e-09</td>
      <td>1.756479e-06</td>
      <td>9.535434e-10</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Australia</td>
      <td>6.278531e-07</td>
      <td>4.320752e-06</td>
      <td>3.217387e-06</td>
      <td>8.288814e-07</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Austria</td>
      <td>1.940654e-07</td>
      <td>1.949988e-07</td>
      <td>1.461246e-05</td>
      <td>6.610069e-06</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Azerbaijan</td>
      <td>3.944116e-08</td>
      <td>1.135804e-06</td>
      <td>1.013838e-07</td>
      <td>1.091433e-08</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Bahamas, The</td>
      <td>6.530293e-09</td>
      <td>4.055567e-07</td>
      <td>3.561719e-06</td>
      <td>2.910584e-08</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Bahrain</td>
      <td>1.140628e-08</td>
      <td>1.547822e-06</td>
      <td>5.975596e-06</td>
      <td>4.285341e-08</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Bangladesh</td>
      <td>2.332117e-09</td>
      <td>6.861480e-11</td>
      <td>2.314621e-07</td>
      <td>1.582571e-11</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Barbados</td>
      <td>6.588651e-09</td>
      <td>3.592553e-08</td>
      <td>1.542933e-06</td>
      <td>2.134390e-08</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Belarus</td>
      <td>3.526892e-08</td>
      <td>6.740231e-08</td>
      <td>1.925372e-06</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Belgium</td>
      <td>6.324726e-07</td>
      <td>1.674076e-06</td>
      <td>2.383903e-05</td>
      <td>8.854531e-06</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Belize</td>
      <td>1.815406e-07</td>
      <td>3.072837e-08</td>
      <td>9.183617e-07</td>
      <td>3.064604e-07</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Benin</td>
      <td>3.984836e-08</td>
      <td>3.014820e-10</td>
      <td>5.891047e-08</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Bermuda</td>
      <td>1.580072e-09</td>
      <td>1.483264e-07</td>
      <td>6.561691e-06</td>
      <td>3.749373e-04</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Bhutan</td>
      <td>1.047904e-09</td>
      <td>9.114236e-10</td>
      <td>1.864709e-07</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Bolivia</td>
      <td>4.269570e-08</td>
      <td>3.035449e-07</td>
      <td>2.578486e-07</td>
      <td>9.064693e-12</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Bonaire, Sint Eustatius and Saba</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Bosnia and Herzegovina</td>
      <td>2.798539e-08</td>
      <td>8.986758e-08</td>
      <td>1.399135e-06</td>
      <td>1.476552e-10</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Botswana</td>
      <td>4.884898e-09</td>
      <td>3.071487e-06</td>
      <td>5.420257e-07</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Bouvet Island</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>30</th>
      <td>Brazil</td>
      <td>1.771807e-07</td>
      <td>1.844335e-07</td>
      <td>6.081129e-07</td>
      <td>8.038374e-08</td>
    </tr>
    <tr>
      <th>31</th>
      <td>British Indian Ocean Ter.</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>32</th>
      <td>British Virgin Islands</td>
      <td>2.306251e-08</td>
      <td>1.453074e-09</td>
      <td>2.170348e-05</td>
      <td>3.866462e-06</td>
    </tr>
    <tr>
      <th>33</th>
      <td>Brunei</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>34</th>
      <td>Bulgaria</td>
      <td>3.239039e-07</td>
      <td>1.655444e-07</td>
      <td>2.989406e-06</td>
      <td>1.020358e-06</td>
    </tr>
    <tr>
      <th>35</th>
      <td>Burkina Faso</td>
      <td>4.107900e-08</td>
      <td>5.079597e-09</td>
      <td>8.245647e-08</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>36</th>
      <td>Burundi</td>
      <td>7.783299e-09</td>
      <td>1.741672e-10</td>
      <td>1.089180e-08</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>37</th>
      <td>Cambodia</td>
      <td>3.144102e-08</td>
      <td>3.875226e-09</td>
      <td>9.464559e-07</td>
      <td>6.342645e-11</td>
    </tr>
    <tr>
      <th>38</th>
      <td>Cameroon</td>
      <td>4.789549e-08</td>
      <td>4.956916e-08</td>
      <td>5.109345e-08</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>39</th>
      <td>Canada</td>
      <td>5.933731e-07</td>
      <td>1.698977e-06</td>
      <td>7.812000e-06</td>
      <td>1.640523e-06</td>
    </tr>
    <tr>
      <th>40</th>
      <td>Cape Verde</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>41</th>
      <td>Cayman Islands</td>
      <td>1.443207e-08</td>
      <td>3.575573e-10</td>
      <td>3.589804e-05</td>
      <td>7.729067e-06</td>
    </tr>
    <tr>
      <th>42</th>
      <td>Central African Republic</td>
      <td>9.010329e-09</td>
      <td>2.536416e-10</td>
      <td>5.236107e-09</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>43</th>
      <td>Chad</td>
      <td>3.735974e-09</td>
      <td>9.554555e-08</td>
      <td>1.317994e-08</td>
      <td>6.867346e-11</td>
    </tr>
    <tr>
      <th>44</th>
      <td>Chile</td>
      <td>4.726555e-07</td>
      <td>8.077881e-07</td>
      <td>2.122852e-06</td>
      <td>2.507734e-07</td>
    </tr>
    <tr>
      <th>45</th>
      <td>China</td>
      <td>1.466312e-08</td>
      <td>5.249644e-09</td>
      <td>1.640766e-06</td>
      <td>9.950255e-08</td>
    </tr>
    <tr>
      <th>46</th>
      <td>Christmas Island</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>47</th>
      <td>Cocos (Keeling) Islands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>48</th>
      <td>Colombia</td>
      <td>1.133073e-07</td>
      <td>3.811224e-07</td>
      <td>3.054313e-07</td>
      <td>3.765721e-08</td>
    </tr>
    <tr>
      <th>49</th>
      <td>Comoros</td>
      <td>6.516405e-08</td>
      <td>0.000000e+00</td>
      <td>2.446683e-08</td>
      <td>0.000000e+00</td>
    </tr>
  </tbody>
</table>
</div>




```python
final_a_imports_pc= final_database_sector.pivot(index='Country', columns='broad_sector', values='imports/pop').reset_index()
```


```python
#Item b)
import geopandas as gpd

#leitura dos dados geográficos de cada país
map_data = gpd.read_file(r'C:\Users\david\OneDrive - Insper - Institudo de Ensino e Pesquisa\Insper\6º semestre\Comércio Internacional\com_int_dados_aps1\ne_110m_admin_0_countries/ne_110m_admin_0_countries.shp')
map_data

#Renomeando "SOVEREIGNT" para "Country"
map_data = map_data.rename(columns = {"SOVEREIGNT" : "Country"})
```


```python
#Base agregada com os dados geográficos e de exportações per capita
final_a_exports_pc_map = pd.merge(map_data, final_a_exports_pc, on='Country')
final_a_exports_pc_map.head(10)

#Base agregada com os dados geográficos e de importações per capita
final_a_imports_pc_map = pd.merge(map_data, final_a_imports_pc, on='Country')
final_a_imports_pc_map.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>featurecla</th>
      <th>scalerank</th>
      <th>LABELRANK</th>
      <th>Country</th>
      <th>SOV_A3</th>
      <th>ADM0_DIF</th>
      <th>LEVEL</th>
      <th>TYPE</th>
      <th>TLC</th>
      <th>ADMIN</th>
      <th>...</th>
      <th>FCLASS_IT</th>
      <th>FCLASS_NL</th>
      <th>FCLASS_SE</th>
      <th>FCLASS_BD</th>
      <th>FCLASS_UA</th>
      <th>geometry</th>
      <th>Agriculture</th>
      <th>Mining &amp; Energy</th>
      <th>Manufacturing</th>
      <th>Services</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Admin-0 country</td>
      <td>1</td>
      <td>6</td>
      <td>Fiji</td>
      <td>FJI</td>
      <td>0</td>
      <td>2</td>
      <td>Sovereign country</td>
      <td>1</td>
      <td>Fiji</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>MULTIPOLYGON (((180.00000 -16.06713, 180.00000...</td>
      <td>1.112722e-08</td>
      <td>0.000000e+00</td>
      <td>8.380298e-06</td>
      <td>1.570114e-08</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Admin-0 country</td>
      <td>1</td>
      <td>7</td>
      <td>Western Sahara</td>
      <td>SAH</td>
      <td>0</td>
      <td>2</td>
      <td>Indeterminate</td>
      <td>1</td>
      <td>Western Sahara</td>
      <td>...</td>
      <td>NaN</td>
      <td>Unrecognized</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>POLYGON ((-8.66559 27.65643, -8.66512 27.58948...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Admin-0 country</td>
      <td>1</td>
      <td>2</td>
      <td>Canada</td>
      <td>CAN</td>
      <td>0</td>
      <td>2</td>
      <td>Sovereign country</td>
      <td>1</td>
      <td>Canada</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>MULTIPOLYGON (((-122.84000 49.00000, -122.9742...</td>
      <td>1.505709e-07</td>
      <td>1.148141e-08</td>
      <td>2.773346e-06</td>
      <td>3.874073e-07</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Admin-0 country</td>
      <td>1</td>
      <td>3</td>
      <td>Kazakhstan</td>
      <td>KA1</td>
      <td>1</td>
      <td>1</td>
      <td>Sovereignty</td>
      <td>1</td>
      <td>Kazakhstan</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>POLYGON ((87.35997 49.21498, 86.59878 48.54918...</td>
      <td>1.110084e-07</td>
      <td>9.895265e-09</td>
      <td>9.999286e-07</td>
      <td>2.614525e-09</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Admin-0 country</td>
      <td>1</td>
      <td>3</td>
      <td>Uzbekistan</td>
      <td>UZB</td>
      <td>0</td>
      <td>2</td>
      <td>Sovereign country</td>
      <td>1</td>
      <td>Uzbekistan</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>POLYGON ((55.96819 41.30864, 55.92892 44.99586...</td>
      <td>5.905817e-09</td>
      <td>2.913137e-11</td>
      <td>6.008493e-08</td>
      <td>7.003033e-11</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Admin-0 country</td>
      <td>1</td>
      <td>2</td>
      <td>Papua New Guinea</td>
      <td>PNG</td>
      <td>0</td>
      <td>2</td>
      <td>Sovereign country</td>
      <td>1</td>
      <td>Papua New Guinea</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>MULTIPOLYGON (((141.00021 -2.60015, 142.73525 ...</td>
      <td>7.929934e-09</td>
      <td>1.332256e-11</td>
      <td>1.125945e-06</td>
      <td>4.315510e-09</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Admin-0 country</td>
      <td>1</td>
      <td>2</td>
      <td>Indonesia</td>
      <td>IDN</td>
      <td>0</td>
      <td>2</td>
      <td>Sovereign country</td>
      <td>1</td>
      <td>Indonesia</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>MULTIPOLYGON (((141.00021 -2.60015, 141.01706 ...</td>
      <td>2.260245e-09</td>
      <td>2.477425e-10</td>
      <td>1.451232e-06</td>
      <td>1.144607e-08</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Admin-0 country</td>
      <td>1</td>
      <td>2</td>
      <td>Argentina</td>
      <td>ARG</td>
      <td>0</td>
      <td>2</td>
      <td>Sovereign country</td>
      <td>1</td>
      <td>Argentina</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>MULTIPOLYGON (((-68.63401 -52.63637, -68.25000...</td>
      <td>3.936866e-09</td>
      <td>4.974426e-10</td>
      <td>1.377282e-07</td>
      <td>7.349834e-10</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Admin-0 country</td>
      <td>1</td>
      <td>2</td>
      <td>Chile</td>
      <td>CHL</td>
      <td>0</td>
      <td>2</td>
      <td>Sovereign country</td>
      <td>1</td>
      <td>Chile</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>MULTIPOLYGON (((-68.63401 -52.63637, -68.63335...</td>
      <td>1.715763e-09</td>
      <td>5.055520e-11</td>
      <td>1.030202e-06</td>
      <td>1.827060e-08</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Admin-0 country</td>
      <td>1</td>
      <td>6</td>
      <td>Somalia</td>
      <td>SOM</td>
      <td>0</td>
      <td>2</td>
      <td>Sovereign country</td>
      <td>1</td>
      <td>Somalia</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>POLYGON ((41.58513 -1.68325, 40.99300 -0.85829...</td>
      <td>2.429005e-08</td>
      <td>5.979309e-09</td>
      <td>9.615580e-07</td>
      <td>0.000000e+00</td>
    </tr>
  </tbody>
</table>
<p>10 rows × 173 columns</p>
</div>




```python
from mpl_toolkits.axes_grid1 import make_axes_locatable 

#Removendo a Antártica, pois influencia negativamente na plotagem do mapa.
world= final_a_imports_pc_map[(final_a_imports_pc_map.Services>0) & (final_a_imports_pc_map.Country!="Antarctica") & (final_a_imports_pc_map['Mining & Energy']>0) & (final_a_imports_pc_map['Manufacturing']>0) & (final_a_imports_pc_map['Agriculture']>0)]
```


```python
import mapclassify
from mpl_toolkits.axes_grid1 import make_axes_locatable

q10 = mapclassify.Quantiles(world.Services, k=5)

fig, ax = plt.subplots(figsize=(16, 9))
world.assign(cl=q10.yb).plot(
    column="Services",
    categorical=True,
    k=2,
    cmap="OrRd",
    linewidth=1,
    edgecolor="white",
    ax=ax
)
ax.set_axis_off()

#Adicionando legenda ao mapa mundi.
divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size="5%", pad=0.1)
sm = plt.cm.ScalarMappable(cmap="OrRd", norm=plt.Normalize(vmin=q10.yb.min(), vmax=q10.yb.max()))
sm._A = []  #Criando um array vazio para evitar erro de vazio
cbar = plt.colorbar(sm, cax=cax)
cbar.ax.set_ylabel("Services", fontsize=14)

# Adicionando título
plt.title("Importações Per Capita pelo Setor de Serviços", fontsize=13)

# Mostrar o plot
plt.show()
```


    
![png](output_30_0.png)
    



```python
q10 = mapclassify.Quantiles(world.Agriculture, k=5)

fig, ax = plt.subplots(figsize=(16, 9))
world.assign(cl=q10.yb).plot(
    column="Agriculture",
    categorical=True,
    k=2,
    cmap="OrRd",
    linewidth=1,
    edgecolor="white",
    ax=ax
)
ax.set_axis_off()


divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size="5%", pad=0.1)
sm = plt.cm.ScalarMappable(cmap="OrRd", norm=plt.Normalize(vmin=q10.yb.min(), vmax=q10.yb.max()))
sm._A = []  
cbar = plt.colorbar(sm, cax=cax)
cbar.ax.set_ylabel("Agriculture", fontsize=14)


plt.title("Importações Per Capita pelo Setor de Agricultura", fontsize=13)


plt.show()
```


    
![png](output_31_0.png)
    



```python
q10 = mapclassify.Quantiles(world['Mining & Energy'], k=5)

fig, ax = plt.subplots(figsize=(16, 9))
world.assign(cl=q10.yb).plot(
    column="Mining & Energy",
    categorical=True,
    k=2,
    cmap="OrRd",
    linewidth=1,
    edgecolor="white",
    ax=ax
)
ax.set_axis_off()


divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size="5%", pad=0.1)
sm = plt.cm.ScalarMappable(cmap="OrRd", norm=plt.Normalize(vmin=q10.yb.min(), vmax=q10.yb.max()))
sm._A = []  
cbar = plt.colorbar(sm, cax=cax)
cbar.ax.set_ylabel("Mining & Energy", fontsize=14)


plt.title("Importações Per Capita pelo Setor de Energia e Mineração", fontsize=13)


plt.show()
```


    
![png](output_32_0.png)
    



```python
q10 = mapclassify.Quantiles(world['Manufacturing'], k=5)

fig, ax = plt.subplots(figsize=(16, 9))
world.assign(cl=q10.yb).plot(
    column="Manufacturing",
    categorical=True,
    k=2,
    cmap="OrRd",
    linewidth=1,
    edgecolor="white",
    ax=ax
)
ax.set_axis_off()


divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size="5%", pad=0.1)
sm = plt.cm.ScalarMappable(cmap="OrRd", norm=plt.Normalize(vmin=q10.yb.min(), vmax=q10.yb.max()))
sm._A = []  
cbar = plt.colorbar(sm, cax=cax)
cbar.ax.set_ylabel("Manufacturing", fontsize=14)


plt.title("Importações Per Capita pelo Setor de Manufatura", fontsize=13)


plt.show()
```


    
![png](output_33_0.png)
    



```python
world_ex= final_a_exports_pc_map[(final_a_exports_pc_map.Services>0) & (final_a_exports_pc_map.Country!="Antarctica") & (final_a_exports_pc_map['Mining & Energy']>0) & (final_a_exports_pc_map['Manufacturing']>0) & (final_a_exports_pc_map['Agriculture']>0)]
```


```python
q10 = mapclassify.Quantiles(world_ex['Mining & Energy'], k=5)

fig, ax = plt.subplots(figsize=(16, 9))
world_ex.assign(cl=q10.yb).plot(
    column="Mining & Energy",
    categorical=True,
    k=2,
    cmap="OrRd",
    linewidth=1,
    edgecolor="white",
    ax=ax
)
ax.set_axis_off()


divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size="5%", pad=0.1)
sm = plt.cm.ScalarMappable(cmap="OrRd", norm=plt.Normalize(vmin=q10.yb.min(), vmax=q10.yb.max()))
sm._A = [] 
cbar = plt.colorbar(sm, cax=cax)
cbar.ax.set_ylabel("Mining & Energy", fontsize=14)


plt.title("Exportações Per Capita pelo Setor de Mineração & Energia", fontsize=13)


plt.show()
```


    
![png](output_35_0.png)
    



```python
q10 = mapclassify.Quantiles(world_ex.Manufacturing, k=5)

fig, ax = plt.subplots(figsize=(16, 9))
world_ex.assign(cl=q10.yb).plot(
    column="Manufacturing",
    categorical=True,
    k=2,
    cmap="OrRd",
    linewidth=1,
    edgecolor="white",
    ax=ax
)
ax.set_axis_off()


divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size="5%", pad=0.1)
sm = plt.cm.ScalarMappable(cmap="OrRd", norm=plt.Normalize(vmin=q10.yb.min(), vmax=q10.yb.max()))
sm._A = [] 
cbar = plt.colorbar(sm, cax=cax)
cbar.ax.set_ylabel("Manufacturing", fontsize=14)


plt.title("Exportações Per Capita pelo Setor de Manufatura", fontsize=13)


plt.show()
```


    
![png](output_36_0.png)
    



```python
q10 = mapclassify.Quantiles(world_ex.Agriculture, k=5)

fig, ax = plt.subplots(figsize=(16, 9))
world_ex.assign(cl=q10.yb).plot(
    column="Agriculture",
    categorical=True,
    k=2,
    cmap="OrRd",
    linewidth=1,
    edgecolor="white",
    ax=ax
)
ax.set_axis_off()


divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size="5%", pad=0.1)
sm = plt.cm.ScalarMappable(cmap="OrRd", norm=plt.Normalize(vmin=q10.yb.min(), vmax=q10.yb.max()))
sm._A = [] 
cbar = plt.colorbar(sm, cax=cax)
cbar.ax.set_ylabel("Agriculture", fontsize=14)

plt.title("Exportações Per Capita pelo Setor de  Agricultura", fontsize=13)

# Show the plot
plt.show()
```


    
![png](output_37_0.png)
    



```python
q10 = mapclassify.Quantiles(world_ex.Agriculture, k=5)

fig, ax = plt.subplots(figsize=(16, 9))
world_ex.assign(cl=q10.yb).plot(
    column="Agriculture",
    categorical=True,
    k=2,
    cmap="OrRd",
    linewidth=1,
    edgecolor="white",
    ax=ax
)
ax.set_axis_off()


divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size="5%", pad=0.1)
sm = plt.cm.ScalarMappable(cmap="OrRd", norm=plt.Normalize(vmin=q10.yb.min(), vmax=q10.yb.max()))
sm._A = [] 
cbar = plt.colorbar(sm, cax=cax)
cbar.ax.set_ylabel("Services", fontsize=14)

plt.title("Exportações Per Capita pelo Setor de Serviço", fontsize=13)

# Show the plot
plt.show()
```


    
![png](output_38_0.png)
    



```python
#Item c

# Agrupar os dados por setor
final_database_sector_filtrada = final_database_sector.drop(['GDP', 'Population','imports','exports/pop','imports/pop'], axis=1)
setores = final_database_sector_filtrada.groupby('broad_sector')

# Classificar os grupos em ordem decrescente com base nos valores de exportação absolutos
setores_export = setores.apply(lambda x: x.nlargest(5, ['exports']))
setores_export
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Country</th>
      <th>broad_sector</th>
      <th>exports</th>
    </tr>
    <tr>
      <th>broad_sector</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Agriculture</th>
      <th>920</th>
      <td>United States</td>
      <td>Agriculture</td>
      <td>72.068645</td>
    </tr>
    <tr>
      <th>96</th>
      <td>Brazil</td>
      <td>Agriculture</td>
      <td>36.528111</td>
    </tr>
    <tr>
      <th>580</th>
      <td>Netherlands</td>
      <td>Agriculture</td>
      <td>25.791887</td>
    </tr>
    <tr>
      <th>144</th>
      <td>Canada</td>
      <td>Agriculture</td>
      <td>21.426398</td>
    </tr>
    <tr>
      <th>172</th>
      <td>China</td>
      <td>Agriculture</td>
      <td>20.215533</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">Mining &amp; Energy</th>
      <th>717</th>
      <td>Russia</td>
      <td>Mining &amp; Energy</td>
      <td>115.987843</td>
    </tr>
    <tr>
      <th>761</th>
      <td>Saudi Arabia</td>
      <td>Mining &amp; Energy</td>
      <td>104.950706</td>
    </tr>
    <tr>
      <th>41</th>
      <td>Australia</td>
      <td>Mining &amp; Energy</td>
      <td>104.522912</td>
    </tr>
    <tr>
      <th>145</th>
      <td>Canada</td>
      <td>Mining &amp; Energy</td>
      <td>61.349203</td>
    </tr>
    <tr>
      <th>409</th>
      <td>Iraq</td>
      <td>Mining &amp; Energy</td>
      <td>46.060823</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">Manufacturing</th>
      <th>174</th>
      <td>China</td>
      <td>Manufacturing</td>
      <td>2262.066360</td>
    </tr>
    <tr>
      <th>922</th>
      <td>United States</td>
      <td>Manufacturing</td>
      <td>1225.300472</td>
    </tr>
    <tr>
      <th>326</th>
      <td>Germany</td>
      <td>Manufacturing</td>
      <td>1194.589090</td>
    </tr>
    <tr>
      <th>434</th>
      <td>Japan</td>
      <td>Manufacturing</td>
      <td>702.802649</td>
    </tr>
    <tr>
      <th>454</th>
      <td>Korea, South</td>
      <td>Manufacturing</td>
      <td>546.633659</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">Services</th>
      <th>923</th>
      <td>United States</td>
      <td>Services</td>
      <td>609.676806</td>
    </tr>
    <tr>
      <th>327</th>
      <td>Germany</td>
      <td>Services</td>
      <td>243.695300</td>
    </tr>
    <tr>
      <th>911</th>
      <td>United Kingdom</td>
      <td>Services</td>
      <td>203.054463</td>
    </tr>
    <tr>
      <th>295</th>
      <td>France</td>
      <td>Services</td>
      <td>183.651238</td>
    </tr>
    <tr>
      <th>583</th>
      <td>Netherlands</td>
      <td>Services</td>
      <td>169.690318</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Agrupar os dados por setor
final_database_sector_filtrada = final_database_sector.drop(['GDP', 'Population','exports','exports/pop','imports/pop'], axis=1)
setores = final_database_sector_filtrada.groupby('broad_sector')

# Classificar os grupos em ordem decrescente com base nos valores de importações absolutos
setores_export = setores.apply(lambda x: x.nlargest(5, ['imports']))
setores_export
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Country</th>
      <th>broad_sector</th>
      <th>imports</th>
    </tr>
    <tr>
      <th>broad_sector</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Agriculture</th>
      <th>920</th>
      <td>United States</td>
      <td>Agriculture</td>
      <td>402.382474</td>
    </tr>
    <tr>
      <th>176</th>
      <td>Taiwan</td>
      <td>Agriculture</td>
      <td>161.726022</td>
    </tr>
    <tr>
      <th>536</th>
      <td>Mexico</td>
      <td>Agriculture</td>
      <td>83.889600</td>
    </tr>
    <tr>
      <th>908</th>
      <td>United Kingdom</td>
      <td>Agriculture</td>
      <td>78.012073</td>
    </tr>
    <tr>
      <th>424</th>
      <td>Cote d'Ivoire</td>
      <td>Agriculture</td>
      <td>71.571072</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">Mining &amp; Energy</th>
      <th>921</th>
      <td>United States</td>
      <td>Mining &amp; Energy</td>
      <td>268.799406</td>
    </tr>
    <tr>
      <th>341</th>
      <td>Greece</td>
      <td>Mining &amp; Energy</td>
      <td>66.361577</td>
    </tr>
    <tr>
      <th>909</th>
      <td>United Kingdom</td>
      <td>Mining &amp; Energy</td>
      <td>42.484061</td>
    </tr>
    <tr>
      <th>397</th>
      <td>India</td>
      <td>Mining &amp; Energy</td>
      <td>11.213541</td>
    </tr>
    <tr>
      <th>693</th>
      <td>Portugal</td>
      <td>Mining &amp; Energy</td>
      <td>6.214357</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">Manufacturing</th>
      <th>918</th>
      <td>Tanzania</td>
      <td>Manufacturing</td>
      <td>1181.681899</td>
    </tr>
    <tr>
      <th>178</th>
      <td>Taiwan</td>
      <td>Manufacturing</td>
      <td>814.092370</td>
    </tr>
    <tr>
      <th>922</th>
      <td>United States</td>
      <td>Manufacturing</td>
      <td>758.318544</td>
    </tr>
    <tr>
      <th>434</th>
      <td>Japan</td>
      <td>Manufacturing</td>
      <td>728.398956</td>
    </tr>
    <tr>
      <th>174</th>
      <td>China</td>
      <td>Manufacturing</td>
      <td>680.868555</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">Services</th>
      <th>175</th>
      <td>China</td>
      <td>Services</td>
      <td>161.367592</td>
    </tr>
    <tr>
      <th>423</th>
      <td>Italy</td>
      <td>Services</td>
      <td>29.478977</td>
    </tr>
    <tr>
      <th>71</th>
      <td>Belgium</td>
      <td>Services</td>
      <td>24.248406</td>
    </tr>
    <tr>
      <th>295</th>
      <td>France</td>
      <td>Services</td>
      <td>20.318425</td>
    </tr>
    <tr>
      <th>771</th>
      <td>Serbia</td>
      <td>Services</td>
      <td>17.796969</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Agrupar os dados por setor
final_database_sector_filtrada = final_database_sector.drop(['GDP', 'Population','exports', 'imports','imports/pop'], axis=1)
setores = final_database_sector_filtrada.groupby('broad_sector')

# Classificar os grupos em ordem decrescente com base nos valores de exportações per capita
setores_export = setores.apply(lambda x: x.nlargest(5, ['exports/pop']))
setores_export
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Country</th>
      <th>broad_sector</th>
      <th>exports/pop</th>
    </tr>
    <tr>
      <th>broad_sector</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Agriculture</th>
      <th>580</th>
      <td>Netherlands</td>
      <td>Agriculture</td>
      <td>1.514469e-06</td>
    </tr>
    <tr>
      <th>212</th>
      <td>Costa Rica</td>
      <td>Agriculture</td>
      <td>7.332099e-07</td>
    </tr>
    <tr>
      <th>612</th>
      <td>New Zealand</td>
      <td>Agriculture</td>
      <td>7.118574e-07</td>
    </tr>
    <tr>
      <th>68</th>
      <td>Belgium</td>
      <td>Agriculture</td>
      <td>6.324726e-07</td>
    </tr>
    <tr>
      <th>40</th>
      <td>Australia</td>
      <td>Agriculture</td>
      <td>6.278531e-07</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">Mining &amp; Energy</th>
      <th>709</th>
      <td>Qatar</td>
      <td>Mining &amp; Energy</td>
      <td>1.361889e-05</td>
    </tr>
    <tr>
      <th>457</th>
      <td>Kuwait</td>
      <td>Mining &amp; Energy</td>
      <td>7.242532e-06</td>
    </tr>
    <tr>
      <th>637</th>
      <td>Norway</td>
      <td>Mining &amp; Energy</td>
      <td>6.605637e-06</td>
    </tr>
    <tr>
      <th>869</th>
      <td>United Arab Emirates</td>
      <td>Mining &amp; Energy</td>
      <td>4.797865e-06</td>
    </tr>
    <tr>
      <th>41</th>
      <td>Australia</td>
      <td>Mining &amp; Energy</td>
      <td>4.320752e-06</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">Manufacturing</th>
      <th>154</th>
      <td>Cayman Islands</td>
      <td>Manufacturing</td>
      <td>3.589804e-05</td>
    </tr>
    <tr>
      <th>782</th>
      <td>Singapore</td>
      <td>Manufacturing</td>
      <td>3.522837e-05</td>
    </tr>
    <tr>
      <th>838</th>
      <td>Switzerland</td>
      <td>Manufacturing</td>
      <td>3.461559e-05</td>
    </tr>
    <tr>
      <th>414</th>
      <td>Ireland</td>
      <td>Manufacturing</td>
      <td>3.308574e-05</td>
    </tr>
    <tr>
      <th>498</th>
      <td>Luxembourg</td>
      <td>Manufacturing</td>
      <td>2.572329e-05</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">Services</th>
      <th>75</th>
      <td>Bermuda</td>
      <td>Services</td>
      <td>3.749373e-04</td>
    </tr>
    <tr>
      <th>499</th>
      <td>Luxembourg</td>
      <td>Services</td>
      <td>1.437471e-04</td>
    </tr>
    <tr>
      <th>415</th>
      <td>Ireland</td>
      <td>Services</td>
      <td>2.352519e-05</td>
    </tr>
    <tr>
      <th>783</th>
      <td>Singapore</td>
      <td>Services</td>
      <td>1.228400e-05</td>
    </tr>
    <tr>
      <th>839</th>
      <td>Switzerland</td>
      <td>Services</td>
      <td>9.980300e-06</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Agrupar os dados por setor
final_database_sector_filtrada = final_database_sector.drop(['GDP', 'Population','exports', 'exports/pop','imports'], axis=1)
setores = final_database_sector_filtrada.groupby('broad_sector')

# Classificar os grupos em ordem decrescente com base nos valores de importações per capita
setores_export = setores.apply(lambda x: x.nlargest(5, ['imports/pop']))
setores_export
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>Country</th>
      <th>broad_sector</th>
      <th>imports/pop</th>
    </tr>
    <tr>
      <th>broad_sector</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="5" valign="top">Agriculture</th>
      <th>240</th>
      <td>Dominica</td>
      <td>Agriculture</td>
      <td>0.000102</td>
    </tr>
    <tr>
      <th>152</th>
      <td>Cayman Islands</td>
      <td>Agriculture</td>
      <td>0.000032</td>
    </tr>
    <tr>
      <th>312</th>
      <td>Georgia</td>
      <td>Agriculture</td>
      <td>0.000014</td>
    </tr>
    <tr>
      <th>836</th>
      <td>Switzerland</td>
      <td>Agriculture</td>
      <td>0.000007</td>
    </tr>
    <tr>
      <th>692</th>
      <td>Portugal</td>
      <td>Agriculture</td>
      <td>0.000005</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">Mining &amp; Energy</th>
      <th>153</th>
      <td>Cayman Islands</td>
      <td>Mining &amp; Energy</td>
      <td>0.000020</td>
    </tr>
    <tr>
      <th>113</th>
      <td>British Virgin Islands</td>
      <td>Mining &amp; Energy</td>
      <td>0.000014</td>
    </tr>
    <tr>
      <th>393</th>
      <td>Iceland</td>
      <td>Mining &amp; Energy</td>
      <td>0.000012</td>
    </tr>
    <tr>
      <th>73</th>
      <td>Bermuda</td>
      <td>Mining &amp; Energy</td>
      <td>0.000008</td>
    </tr>
    <tr>
      <th>341</th>
      <td>Greece</td>
      <td>Mining &amp; Energy</td>
      <td>0.000006</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">Manufacturing</th>
      <th>334</th>
      <td>Gibraltar</td>
      <td>Manufacturing</td>
      <td>0.004133</td>
    </tr>
    <tr>
      <th>114</th>
      <td>British Virgin Islands</td>
      <td>Manufacturing</td>
      <td>0.002063</td>
    </tr>
    <tr>
      <th>394</th>
      <td>Iceland</td>
      <td>Manufacturing</td>
      <td>0.001203</td>
    </tr>
    <tr>
      <th>586</th>
      <td>Curacao</td>
      <td>Manufacturing</td>
      <td>0.001180</td>
    </tr>
    <tr>
      <th>154</th>
      <td>Cayman Islands</td>
      <td>Manufacturing</td>
      <td>0.000737</td>
    </tr>
    <tr>
      <th rowspan="5" valign="top">Services</th>
      <th>795</th>
      <td>Slovenia</td>
      <td>Services</td>
      <td>0.000003</td>
    </tr>
    <tr>
      <th>771</th>
      <td>Serbia</td>
      <td>Services</td>
      <td>0.000003</td>
    </tr>
    <tr>
      <th>71</th>
      <td>Belgium</td>
      <td>Services</td>
      <td>0.000002</td>
    </tr>
    <tr>
      <th>271</th>
      <td>Estonia</td>
      <td>Services</td>
      <td>0.000001</td>
    </tr>
    <tr>
      <th>395</th>
      <td>Iceland</td>
      <td>Services</td>
      <td>0.000001</td>
    </tr>
  </tbody>
</table>
</div>




```python
itpd_brazil = itpd_ie_sector[itpd_ie_sector['Country'] == 'Brazil']
itpd_brazil
total_export = itpd_brazil['exports'].sum()
total_export
itpd_brazil['% Sector in Total Exports'] = (itpd_brazil['exports']/total_export) * 100
itpd_brazil
# Configurando o tamanho da figura
plt.figure(figsize=(8, 8))

# Criando o gráfico de setores
plt.pie(itpd_brazil['% Sector in Total Exports'], labels=itpd_brazil['broad_sector'], autopct='%1.1f%%')

# Título
plt.title('% Sector in Total Exports for Brazil')

# Mostrando o gráfico
plt.show()
total_import = itpd_brazil['imports'].sum()
itpd_brazil['% Sector in Total Imports'] = (itpd_brazil['imports']/total_export) * 100


plt.figure(figsize=(8, 8))


plt.pie(itpd_brazil['% Sector in Total Imports'], labels=itpd_brazil['broad_sector'], autopct='%1.1f%%')


plt.title('% Sector in Total Imports for Brazil')


plt.show()
itpd_india = itpd_ie_sector[itpd_ie_sector['Country'] == 'India']
itpd_india
total_export_india = itpd_india['exports'].sum()
total_export_india
itpd_india['% Sector in Total Exports'] = (itpd_india['exports']/total_export_india) * 100
itpd_india

plt.figure(figsize=(8, 8))


plt.pie(itpd_india['% Sector in Total Exports'], labels=itpd_india['broad_sector'], autopct='%1.1f%%')


plt.title('% Sector in Total Exports for India')


plt.show()
total_imports_india = itpd_india['imports'].sum()
itpd_india['% Sector in Total Imports'] = (itpd_india['imports']/total_export) * 100


plt.figure(figsize=(8, 8))


plt.pie(itpd_india['% Sector in Total Imports'], labels=itpd_india['broad_sector'], autopct='%1.1f%%')


plt.title('% Sector in Total Imports for India')


plt.show()

```

    C:\Users\david\AppData\Local\Temp\ipykernel_1756\1342131497.py:5: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
    


    
![png](output_43_1.png)
    


    C:\Users\david\AppData\Local\Temp\ipykernel_1756\1342131497.py:19: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
    


    
![png](output_43_3.png)
    


    C:\Users\david\AppData\Local\Temp\ipykernel_1756\1342131497.py:36: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
    


    
![png](output_43_5.png)
    


    C:\Users\david\AppData\Local\Temp\ipykernel_1756\1342131497.py:50: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
    


    
![png](output_43_7.png)
    

